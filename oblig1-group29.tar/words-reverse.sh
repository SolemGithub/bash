#!/bin/bash

if [ ! -z $2 ] 
then
echo "multiple arguments passed"

fi
if [[ $1 == "--bypass" ]]

 then
 echo "allowed argument passed program starts"
 tekst="lorem ipsum dolor
 hjahe heh eha eoe !.  ge e
 a h o ø. 
 h. hee"
 
 read -p "enter dir" dir
 
 echo $dir




mkdir $dir
echo $tekst > tekst.txt
tekstdir=tekst.txt

bash depunctuate.sh $tekstdir $2
bash repunctuate.sh $tekstdir $2



# both Depunctate.sh and Repunctate.sh reads from tekst.txt and does their actions 



# echo $(bash Repunctate.sh $(bash Depunctate.sh $FILES $tekst ) )
 #echo $(bash Repunctate.sh $(bash words-reverse $(bash Depunctate.sh $FILES $tekst ) ))



else
echo "no valid argument passed"
>&2
exit 
fi 