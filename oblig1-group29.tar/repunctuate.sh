#!/bash/
FILES="$1/*"



for f in $FILES
do

    Lines="$(cat tekst.txt)"


c=$( echo $f | cut -d "." -f 1  )
c=$(echo $c | cut -d "/" -f 2 )


replace=$(cat $f)
searchfor=$c

sed -i "s/$searchfor/$replace/g" "tekst.txt"



done

reAssemble () {

sed -i -z "s/\n,/,/g" tekst.txt
sed -i -z "s/\n[.]/./g" tekst.txt
sed -i -z "s/\n|\n/|/g" tekst.txt
sed -i -z "s/\n/ /g" tekst.txt
sed -i -z "s/|/\n/g" tekst.txt

}

reAssemble

cat tekst.txt


