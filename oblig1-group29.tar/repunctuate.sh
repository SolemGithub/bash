#!/bin/bash


FILES="$2/*"
if [ ! -f "tekst.txt" ]; then
echo a > tekst.txt
fi
#sets path to the directory 


for f in $FILES
do

# for every file in dir 

    Lines="$(cat tekst.txt)"
#count the lines 

c=$( echo $f | cut -d "." -f 1  )
#cuts away .txt
c=$(echo $c | cut -d "/" -f 2 )

# and the $1/ filepath 

replace=$(cat $f)
searchfor=$c
#sets what to search for and replace
sed -i "s/$searchfor/$replace/g" "tekst.txt"
#replaces them 


done

reAssemble () {

sed -i -z "s/\n,/,/g" tekst.txt
sed -i -z "s/\n[.]/./g" tekst.txt
sed -i -z "s/\n|\n/|/g" tekst.txt
sed -i -z "s/\n/ /g" tekst.txt
sed -i -z "s/|/\n/g" tekst.txt
#reAssembles the text back to its original state
#could have used for loop
}

reAssemble
#calls on reAssemble 

set $(cat tekst.txt)






