FILES="$1/*"
#FILES=$1


for f in $FILES
do
#  echo "Processing $f file..."
  # take action on each file. $f store current file name

             # echo $Line > "temp/"$(echo
    Lines="$(cat tekst.txt)"


c=$( echo $f | cut -d "." -f 1  )
c=$(echo $c | cut -d "/" -f 2 )
#echo $c

replace=$(cat $f)
searchfor=$c

sed -i "s/$searchfor/$replace/g" "tekst.txt"

#echo "$searchfor"" this is search for"
#echo "$replace"" this is replace"


 # cat "$f"


done

reAssemble () {
#re assembles the file 
sed -i -z "s/\n,/,/g" tekst.txt
sed -i -z "s/\n[.]/./g" tekst.txt
sed -i -z "s/\n|\n/|/g" tekst.txt
sed -i -z "s/\n/ /g" tekst.txt
sed -i -z "s/|/\n/g" tekst.txt

}

reAssemble

cat tekst.txt
 echo a


