#!/bin/bash

set -e
directory=tekst.txt




if [ ! -f "tekst.txt" ]; then
echo a > tekst.txt
fi


sed -i -z "s/\n/|/g" tekst.txt
sed -i -z "s/ /\n/g" tekst.txt
sed -i -z "s/|/\n|/g" tekst.txt
sed -i -z "s/|/|\n/g" tekst.txt
sed -i -z "s/,/\n,/g" tekst.txt
sed -i -z "s/[.]/\n./g" tekst.txt
#makes the script line by line 
#with replacing the values 
#could also have been done with a for loop and an array if there where more replacements




exists(){
if [ -f "$1" ]; then

  
   if cmp --silent -- "$1" "$2"; then echo  else echo "files differ">&2 
   fi

#checks if the script exsists
fi
}


exists

linecount=0;
#linecount is used to determine what line to replace

Lines="$(cat tekst.txt)"


for line in $Lines 
do


linecount=$(($linecount+1))
#increments linecount

   if [[ $line == *['!|'@#\$%^\&*()_+,.]* ]]
   then 
#if the line contains special characters

  
   exists "$directory $tekst"

   hash="$(echo $line | sha256sum | cut -d " " -f 1)"
     echo $hash > tempfile.txt
    
     

      echo $line > chmod u+x "$2/"$(cat tempfile.txt).txt
  #uses tempfile as temporary storage
     
      
     sed -i ''$linecount's/.*/'$hash'/' tekst.txt
     #replaces the punctation with its hash 
  
   fi
done

echo $(cat tekst.txt)
cat tekst.txt









