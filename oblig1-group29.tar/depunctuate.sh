


set -e

directory=tekst.txt




sed -i -z "s/\n/|/g" tekst.txt
sed -i -z "s/ /\n/g" tekst.txt
sed -i -z "s/|/\n|/g" tekst.txt
sed -i -z "s/|/|\n/g" tekst.txt
sed -i -z "s/,/\n,/g" tekst.txt
sed -i -z "s/[.]/\n./g" tekst.txt






exists(){
if [ -f "$2" ]; then

  
   if cmp --silent -- "$1" "$2"; then echo  else echo "files differ">&2 
   fi


fi
}


exists
linecount=0;

Lines="$(cat tekst.txt)"


for line in $Lines 
do


linecount=$(($linecount+1))


   if [[ $line == *['!|'@#\$%^\&*()_+,.]* ]]
   then 


  
   exists "$directory $2"

   hash="$(echo $line | sha256sum | cut -d " " -f 1)"
     echo $hash > tempfile.txt
    
     

      echo $line > "$1/"$(cat tempfile.txt).txt
  
     
      
     sed -i ''$linecount's/.*/'$hash'/' tekst.txt
  
   fi
done








