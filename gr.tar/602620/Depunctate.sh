


set -e

directory=tekst.txt
#echo $2> temptextfile.txt



sed -i -z "s/\n/|/g" tekst.txt
sed -i -z "s/ /\n/g" tekst.txt
sed -i -z "s/|/\n|/g" tekst.txt
sed -i -z "s/|/|\n/g" tekst.txt
sed -i -z "s/,/\n,/g" tekst.txt
sed -i -z "s/[.]/\n./g" tekst.txt





# echo temptextfile.txt
exists(){
if [ -f "$2" ]; then

   # echo "$2 exists."
   if cmp --silent -- "$1" "$2"; then echo  else echo "files differ">&2 
   fi


fi
}


exists
linecount=0;

Lines="$(cat tekst.txt)"


for line in $Lines 
do


linecount=$(($linecount+1))
#echo $linecount
   # do something with $line here
#echo $line

   if [[ $line == *['!|'@#\$%^\&*()_+,.]* ]]
   then 
  # echo $line" this line "

  
   exists "$directory $2"

   # echo $hashes
   hash="$(echo $line | sha256sum | cut -d " " -f 1)"
     echo $hash > tempfile.txt
    
     

     # cat tempfile.txt 
    
      echo $line > "$1/"$(cat tempfile.txt).txt
    #  echo "IMPORTANT"
    #  echo "temp/"$(cat tempfile.txt)".txt"
      #line="$(cat tempfile.txt)"
     
      
      #echo $line "special line"
      
     sed -i ''$linecount's/.*/'$hash'/' tekst.txt
    
     #echo "if works";
   fi
done




# echo $2" this is the text"





