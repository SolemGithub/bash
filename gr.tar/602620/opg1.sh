set -e
echo  $(cat a.txt) > tekst.txt



#tr ['\n'] ['|'] > tekst.txt
#cat tekst.txt | tr [' '] ['\n'] > tekst.txt
#sed -z 's/'[.]'/\n./gI' s.txt | tee s.txt
#sed ':a;N;$!ba;s/\n/,/g'  tekst.txt 
#sed -i "s/\n/|/" tekst.txt
#sed 's/'[,]'/\n,/gI' tekst.txt | tee tekst.txt

sed -i -z "s/\n/|/g" tekst.txt
sed -i -z "s/ /\n/g" tekst.txt
sed -i -z "s/|/\n|/g" tekst.txt
sed -i -z "s/|/|\n/g" tekst.txt
sed -i -z "s/,/\n,/g" tekst.txt
sed -i -z "s/[.]/\n./g" tekst.txt



cat tekst.txt 

